
public class Node {
    Elemento elemento;
    Node proximo;

    public Node(Elemento elemento) {
        this.elemento = elemento;
        this.proximo = null;
    }
}
